# RallyMapper Roadbook Engine Starter Bundle

This starter bundle is designed to drop into your existing `src/roadbook/` folder.

## Included modules

- `roadbookEngine.js` — orchestrates the pipeline
- `trackPreprocessor.js` — cleans and simplifies track data
- `turnDetection.js` — detects turn candidates from GPS geometry
- `eventClassifier.js` — maps turn angles to rally-style event types
- `waypointMerger.js` — merges manual waypoints into derived events
- `tulipRenderer.js` — renders basic SVG tulips
- `roadbookExporter.js` — exports JSON and CSV
- `roadbookTypes.js` — shared event type constants
- `geo.js` — geometry helpers
- `index.js` — convenience exports

## Expected stage shape

```js
const stage = {
  meta: {
    stageName: "Section 1",
    day: "Day 1",
    recorder: "Roger",
    startedAt: "2026-03-08T10:15:00Z",
  },
  trackPoints: [
    {
      id: "tp1",
      lat: -30.12345,
      lon: 138.23456,
      time: "2026-03-08T10:15:02Z",
      distanceFromStartM: 0,
    },
  ],
  waypoints: [
    {
      id: "wp1",
      lat: -30.12410,
      lon: 138.23520,
      time: "2026-03-08T10:16:10Z",
      distanceFromStartM: 420,
      icon: "gate",
      note: "Fence gate",
    },
  ],
}
```

## Quick test

```js
import { generateRoadbook, exportRoadbookCsv } from "@/roadbook"

const roadbook = generateRoadbook(stage)
const csv = exportRoadbookCsv(roadbook)
console.log(roadbook)
console.log(csv)
```

## Integration recommendation

Do not run this live during recording yet.
Trigger it only on:

- End Stage, or
- Export

That keeps your iPad PWA stable while you field test the generator.
